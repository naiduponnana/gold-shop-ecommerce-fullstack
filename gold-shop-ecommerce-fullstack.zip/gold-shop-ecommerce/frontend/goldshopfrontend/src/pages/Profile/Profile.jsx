import { useState } from 'react';

function Profile() {
  const savedUser = JSON.parse(localStorage.getItem('ssp_user') || '{}');
  const [form, setForm] = useState({
    name: savedUser.name || '',
    mobile: savedUser.mobile || '',
    email: savedUser.email || '',
    address: savedUser.address || ''
  });
  const [message, setMessage] = useState('');

  const update = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));

  const submit = (event) => {
    event.preventDefault();
    localStorage.setItem('ssp_user', JSON.stringify({ id: savedUser.id || 1, ...form }));
    setMessage('Profile updated successfully.');
  };

  return (
    <section className="container page-space narrow-page">
      <div className="page-title-row"><div><span className="eyebrow">Account</span><h1>My Profile</h1></div></div>
      <form className="card-panel profile-form" onSubmit={submit}>
        <label>Name<input name="name" value={form.name} onChange={update} required /></label>
        <label>Mobile<input name="mobile" value={form.mobile} onChange={update} required /></label>
        <label>Email<input type="email" name="email" value={form.email} onChange={update} required /></label>
        <label>Address<textarea name="address" value={form.address} onChange={update} /></label>
        <button className="primary-btn">Update Profile</button>
        {message && <p className="success-message">{message}</p>}
      </form>
    </section>
  );
}

export default Profile;
