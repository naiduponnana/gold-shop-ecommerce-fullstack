import { Link } from 'react-router-dom';
import { FiArrowRight, FiAward, FiGift, FiMapPin, FiShield } from 'react-icons/fi';
import HeroBanner from '../../components/HeroBanner.jsx';
import CategoryCard from '../../components/CategoryCard.jsx';
import ProductCard from '../../components/ProductCard.jsx';
import { categoryCards, featuredProducts } from '../../data/products.js';

function Home() {
  return (
    <>
      <HeroBanner />

      <section className="section container">
        <div className="section-heading">
          <span>Curated categories</span>
          <h2>Shop by jewellery style</h2>
          <p>Browse premium gold, diamond, bridal and gifting jewellery designed for every occasion.</p>
        </div>
        <div className="category-grid">
          {categoryCards.map((category) => <CategoryCard key={category.title} category={category} />)}
        </div>
      </section>

      <section className="collection-band container">
        <div className="collection-copy">
          <FiGift />
          <span>Gift Collection</span>
          <h2>Gold gifts that stay meaningful for generations</h2>
          <p>Choose elegant coins, pendants, rings and curated jewellery gift sets for weddings, anniversaries and festivals.</p>
          <Link to="/products?category=Gifting" className="primary-btn">Explore Gifts <FiArrowRight /></Link>
        </div>
        <img src="/images/banners/banner-gifting.svg" alt="Gold gifting collection" />
      </section>

      <section className="wedding-section">
        <div className="container wedding-grid">
          <img src="/images/banners/banner-wedding.svg" alt="Wedding jewellery" />
          <div>
            <span className="eyebrow">Wedding Jewellery</span>
            <h2>Bridal pieces crafted for the most important day</h2>
            <p>From antique harams to engagement rings, our wedding jewellery collection balances tradition, purity and premium finishing.</p>
            <div className="trust-row">
              <span><FiShield /> BIS Hallmark</span>
              <span><FiAward /> Certified Quality</span>
            </div>
            <Link to="/products?category=Wedding%20Jewellery" className="secondary-btn">View Wedding Collection</Link>
          </div>
        </div>
      </section>

      <section className="store-locator-band container">
        <div>
          <span className="eyebrow">Locate Store</span>
          <h2>Experience jewellery in our showroom</h2>
          <p>Book a store visit, compare designs, verify purity and receive expert guidance from our jewellery consultants.</p>
        </div>
        <Link to="/contact" className="outline-btn"><FiMapPin /> Find Nearest Store</Link>
      </section>

      <section className="section container">
        <div className="section-heading row-heading">
          <div>
            <span>Featured designs</span>
            <h2>Premium picks from Sai Swarana Palase</h2>
          </div>
          <Link to="/products" className="text-link">View all products <FiArrowRight /></Link>
        </div>
        <div className="product-grid">
          {featuredProducts.map((product) => <ProductCard key={product.id} product={product} />)}
        </div>
      </section>
    </>
  );
}

export default Home;
