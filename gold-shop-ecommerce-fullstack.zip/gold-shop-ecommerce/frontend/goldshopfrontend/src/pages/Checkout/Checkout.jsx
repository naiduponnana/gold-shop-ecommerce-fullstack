import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { products } from '../../data/products.js';

const formatCurrency = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
const readCart = () => { try { return JSON.parse(localStorage.getItem('ssp_cart')) || []; } catch { return []; } };

function Checkout() {
  const navigate = useNavigate();
  const [cart] = useState(readCart());
  const [form, setForm] = useState({ fullName: '', mobile: '', email: '', address: '', city: '', state: '', pincode: '' });

  const items = useMemo(() => cart.map((item) => ({ ...item, product: products.find((product) => product.id === item.productId) })).filter((item) => item.product), [cart]);
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const making = Math.round(subtotal * 0.08);
  const total = subtotal + making;

  const update = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));

  const placeOrder = (event) => {
    event.preventDefault();
    if (!items.length) return;
    const orders = JSON.parse(localStorage.getItem('ssp_orders') || '[]');
    const newOrder = {
      id: `SSP-${Date.now()}`,
      date: new Date().toLocaleDateString('en-IN'),
      status: 'Order Placed',
      customer: form,
      items: items.map((item) => ({ productId: item.product.id, quantity: item.quantity, price: item.product.price })),
      total
    };
    localStorage.setItem('ssp_orders', JSON.stringify([newOrder, ...orders]));
    localStorage.setItem('ssp_cart', JSON.stringify([]));
    navigate('/orders');
  };

  return (
    <section className="container page-space">
      <div className="page-title-row"><div><span className="eyebrow">Secure Checkout</span><h1>Billing Details</h1></div></div>
      <form className="checkout-layout" onSubmit={placeOrder}>
        <div className="checkout-form card-panel">
          <div className="form-grid">
            <label>Full Name<input name="fullName" value={form.fullName} onChange={update} required /></label>
            <label>Mobile<input name="mobile" value={form.mobile} onChange={update} required /></label>
            <label>Email<input type="email" name="email" value={form.email} onChange={update} required /></label>
            <label>City<input name="city" value={form.city} onChange={update} required /></label>
            <label>State<input name="state" value={form.state} onChange={update} required /></label>
            <label>Pincode<input name="pincode" value={form.pincode} onChange={update} required /></label>
            <label className="wide">Address<textarea name="address" value={form.address} onChange={update} required /></label>
          </div>
        </div>

        <aside className="summary-card order-summary">
          <h2>Order Summary</h2>
          {items.map((item) => <p key={item.product.id}><span>{item.product.name} × {item.quantity}</span><strong>{formatCurrency(item.product.price * item.quantity)}</strong></p>)}
          <p><span>Making charges</span><strong>{formatCurrency(making)}</strong></p>
          <p className="grand-total"><span>Total</span><strong>{formatCurrency(total)}</strong></p>
          <button className="primary-btn full" disabled={!items.length}>Place Order</button>
        </aside>
      </form>
    </section>
  );
}

export default Checkout;
