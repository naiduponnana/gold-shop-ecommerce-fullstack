import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiSmartphone } from 'react-icons/fi';

function Login() {
  const navigate = useNavigate();
  const [mobile, setMobile] = useState('');

  const submit = (event) => {
    event.preventDefault();
    const user = { id: 1, name: 'Sai Swarana Customer', mobile: `+91${mobile}`, email: 'customer@example.com' };
    localStorage.setItem('ssp_user', JSON.stringify(user));
    navigate('/profile');
  };

  return (
    <section className="auth-page">
      <form className="auth-card" onSubmit={submit}>
        <img src="/images/logo/sai-swarana-logo.svg" alt="Sai Swarana Palase" />
        <span className="eyebrow">OTP Login</span>
        <h1>Welcome back</h1>
        <p>Login with your mobile number to access orders, wishlist and cart.</p>
        <label>Mobile Number</label>
        <div className="phone-input"><span>+91</span><input value={mobile} maxLength="10" placeholder="Enter mobile number" onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))} required /></div>
        <button className="primary-btn full" type="submit"><FiSmartphone /> Send OTP</button>
        <p className="auth-switch">New customer? <Link to="/register">Create account</Link></p>
      </form>
    </section>
  );
}

export default Login;
