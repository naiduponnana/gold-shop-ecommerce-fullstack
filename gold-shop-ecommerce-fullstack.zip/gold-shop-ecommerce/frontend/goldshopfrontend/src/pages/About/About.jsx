import { FiAward, FiCheckCircle, FiShield, FiStar } from 'react-icons/fi';

function About() {
  return (
    <>
      <section className="about-hero page-hero">
        <img src="/images/showroom/showroom-banner.svg" alt="Sai Swarana Palase showroom" />
        <div><span className="eyebrow">About Us</span><h1>Crafting trusted gold jewellery for every celebration</h1></div>
      </section>

      <section className="container section content-section">
        <div>
          <span className="eyebrow">Brand Story</span>
          <h2>Sai Swarana Palase</h2>
          <p>Sai Swarana Palase is a premium jewellery shopping destination created for customers who expect purity, modern service and refined craftsmanship. Our collections include wedding jewellery, gold ornaments, diamond pieces, daily wear jewellery and gifting designs.</p>
          <p>Every design is selected with attention to comfort, finish, weight balance and occasion value so customers can shop with confidence online and in-store.</p>
        </div>
        <img src="/images/showroom/showroom-interior.svg" alt="Jewellery showroom interior" />
      </section>

      <section className="quality-section">
        <div className="container quality-grid">
          <div><FiShield /><h3>Quality First</h3><p>BIS hallmarked gold and transparent product specifications.</p></div>
          <div><FiAward /><h3>Certified Stones</h3><p>Diamond jewellery with clear stone quality and design details.</p></div>
          <div><FiStar /><h3>Premium Finish</h3><p>Elegant finishing, modern styling and traditional craftsmanship.</p></div>
          <div><FiCheckCircle /><h3>Trusted Service</h3><p>Store consultation, secure billing, insured delivery and support.</p></div>
        </div>
      </section>

      <section className="container section">
        <div className="section-heading"><span>Why choose us</span><h2>Jewellery shopping with clarity and confidence</h2></div>
        <div className="why-grid">
          {['Transparent pricing and product details', 'Premium bridal and festive collections', 'Responsive online shopping experience', 'Showroom support for purchase decisions', 'Modern packaging for gifting', 'Secure checkout-ready architecture'].map((item) => <p key={item}><FiCheckCircle /> {item}</p>)}
        </div>
      </section>
    </>
  );
}

export default About;
