import { Link, useParams } from 'react-router-dom';
import { FaStar } from 'react-icons/fa';
import { FiHeart, FiShoppingBag, FiTruck } from 'react-icons/fi';
import ProductCard from '../../components/ProductCard.jsx';
import { products } from '../../data/products.js';

const formatCurrency = (value) => new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
}).format(value);

const getArray = (key) => {
  try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; }
};

function ProductDetails() {
  const { id } = useParams();
  const product = products.find((item) => Number(item.id) === Number(id));

  if (!product) {
    return (
      <section className="container empty-state page-space">
        <h1>Product not found</h1>
        <p>The jewellery design you are looking for is not available.</p>
        <Link to="/products" className="primary-btn">Back to Products</Link>
      </section>
    );
  }

  const related = products.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 4);

  const addToCart = () => {
    const cart = getArray('ssp_cart');
    const existing = cart.find((item) => Number(item.productId) === Number(product.id));
    const updated = existing
      ? cart.map((item) => Number(item.productId) === Number(product.id) ? { ...item, quantity: item.quantity + 1 } : item)
      : [...cart, { productId: product.id, quantity: 1 }];
    localStorage.setItem('ssp_cart', JSON.stringify(updated));
  };

  const addToWishlist = () => {
    const wishlist = getArray('ssp_wishlist');
    if (!wishlist.includes(product.id)) localStorage.setItem('ssp_wishlist', JSON.stringify([...wishlist, product.id]));
  };

  return (
    <>
      <section className="product-detail container page-space">
        <div className="detail-image-card">
          <img src={product.image} alt={product.name} />
        </div>
        <div className="detail-content">
          <span className="eyebrow">{product.category}</span>
          <h1>{product.name}</h1>
          <div className="rating-row"><FaStar /> {product.rating} customer rating</div>
          <div className="detail-price">{formatCurrency(product.price)}</div>
          <p>{product.description}</p>

          <div className="spec-grid">
            <span><strong>Metal Type</strong>{product.metal}</span>
            <span><strong>Purity</strong>{product.purity}</span>
            <span><strong>Weight</strong>{product.weight}</span>
            <span><strong>Category</strong>{product.category}</span>
            <span><strong>Height</strong>{product.height}</span>
            <span><strong>Width</strong>{product.width}</span>
          </div>

          <div className="delivery-note"><FiTruck /> Store pickup, insured delivery and showroom consultation available.</div>
          <div className="detail-actions">
            <button className="primary-btn" onClick={addToCart}><FiShoppingBag /> Add to Cart</button>
            <button className="outline-btn" onClick={addToWishlist}><FiHeart /> Add to Wishlist</button>
          </div>
        </div>
      </section>

      <section className="section container">
        <div className="section-heading row-heading">
          <div>
            <span>Related designs</span>
            <h2>You may also like</h2>
          </div>
          <Link to="/products" className="text-link">View catalogue</Link>
        </div>
        <div className="product-grid">
          {related.map((item) => <ProductCard key={item.id} product={item} />)}
        </div>
      </section>
    </>
  );
}

export default ProductDetails;
