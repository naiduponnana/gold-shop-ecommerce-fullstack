import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FiFilter } from 'react-icons/fi';
import ProductCard from '../../components/ProductCard.jsx';
import { products } from '../../data/products.js';

const filters = {
  type: ['Necklace', 'Ring', 'Earrings', 'Haram', 'Chain', 'Bracelet', 'Bangles', 'Pendant', 'Gold Coin'],
  gender: ['Women', 'Men', 'Unisex', 'Couple'],
  diamondColor: ['F-G', 'G-H', 'NA'],
  diamondClarity: ['VVS-VS', 'VS', 'NA'],
  collection: ['Royal Heritage', 'Lotus Glow', 'Pearl Edit', 'Mangalya', 'Daily Gold', 'Men Classic', 'Maya Shine', 'Nakshi Art', 'Gem Edit', 'Forever Pair', 'Auspicious Gifts', 'Temple Grandeur'],
  purity: ['18K', '22K', '24K'],
  jewelleryType: ['Traditional', 'Contemporary', 'Modern', 'Bridal', 'Minimal', 'Classic', 'Investment'],
  occasion: ['Wedding', 'Engagement', 'Party', 'Daily Wear', 'Gifting', 'Festive']
};

function Products() {
  const [searchParams] = useSearchParams();
  const category = searchParams.get('category') || '';
  const search = (searchParams.get('search') || '').toLowerCase();
  const [sort, setSort] = useState('best');
  const [selected, setSelected] = useState({});
  const [price, setPrice] = useState('all');
  const [mobileFilters, setMobileFilters] = useState(false);

  const toggle = (key, value) => {
    setSelected((current) => {
      const values = current[key] || [];
      return {
        ...current,
        [key]: values.includes(value) ? values.filter((item) => item !== value) : [...values, value]
      };
    });
  };

  const filteredProducts = useMemo(() => {
    let list = products.filter((product) => {
      const categoryMatch = !category || product.category.toLowerCase() === category.toLowerCase();
      const searchMatch = !search || [product.name, product.category, product.type, product.collection, product.occasion]
        .join(' ')
        .toLowerCase()
        .includes(search);
      const priceMatch = price === 'all'
        || (price === 'below50000' && product.price < 50000)
        || (price === '50000to100000' && product.price >= 50000 && product.price <= 100000)
        || (price === 'above100000' && product.price > 100000);

      const selectedMatch = Object.entries(selected).every(([key, values]) => {
        if (!values.length) return true;
        return values.includes(product[key]);
      });

      return categoryMatch && searchMatch && priceMatch && selectedMatch;
    });

    if (sort === 'low') list = [...list].sort((a, b) => a.price - b.price);
    if (sort === 'high') list = [...list].sort((a, b) => b.price - a.price);
    if (sort === 'new') list = [...list].sort((a, b) => b.id - a.id);
    if (sort === 'best') list = [...list].sort((a, b) => b.rating - a.rating);
    return list;
  }, [category, search, selected, sort, price]);

  return (
    <section className="products-page container">
      <div className="page-title-row">
        <div>
          <span className="eyebrow">Jewellery Catalogue</span>
          <h1>{category || 'All Jewellery'}</h1>
          <p>{filteredProducts.length} premium designs available</p>
        </div>
        <button className="filter-toggle" onClick={() => setMobileFilters((value) => !value)}><FiFilter /> Filters</button>
      </div>

      <div className="products-layout">
        <aside className={`filter-sidebar ${mobileFilters ? 'show' : ''}`}>
          <h2>Filters</h2>

          <div className="filter-group">
            <h3>Price</h3>
            {[['all', 'All Prices'], ['below50000', 'Below ₹50,000'], ['50000to100000', '₹50,000 - ₹1,00,000'], ['above100000', 'Above ₹1,00,000']].map(([value, label]) => (
              <label key={value}><input type="radio" name="price" checked={price === value} onChange={() => setPrice(value)} /> {label}</label>
            ))}
          </div>

          {Object.entries(filters).map(([key, values]) => (
            <div className="filter-group" key={key}>
              <h3>{key === 'type' ? 'Product Type' : key.replace(/([A-Z])/g, ' $1')}</h3>
              {values.map((value) => (
                <label key={value}>
                  <input type="checkbox" checked={(selected[key] || []).includes(value)} onChange={() => toggle(key, value)} /> {value}
                </label>
              ))}
            </div>
          ))}
        </aside>

        <div className="listing-area">
          <div className="sort-bar">
            <span>Showing {filteredProducts.length} designs</span>
            <select value={sort} onChange={(event) => setSort(event.target.value)}>
              <option value="best">Best Selling</option>
              <option value="new">New Arrivals</option>
              <option value="low">Price low to high</option>
              <option value="high">Price high to low</option>
            </select>
          </div>

          {filteredProducts.length ? (
            <div className="product-grid listing-grid">
              {filteredProducts.map((product) => <ProductCard key={product.id} product={product} />)}
            </div>
          ) : (
            <div className="empty-state">
              <h2>No jewellery found</h2>
              <p>Try clearing filters or searching another product style.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export default Products;
