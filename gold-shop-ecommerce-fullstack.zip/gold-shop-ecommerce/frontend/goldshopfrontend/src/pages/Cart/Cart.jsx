import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { FiMinus, FiPlus, FiTrash2 } from 'react-icons/fi';
import { products } from '../../data/products.js';

const formatCurrency = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
const readCart = () => { try { return JSON.parse(localStorage.getItem('ssp_cart')) || []; } catch { return []; } };

function Cart() {
  const [cart, setCart] = useState(readCart());

  const items = useMemo(() => cart.map((item) => {
    const product = products.find((entry) => Number(entry.id) === Number(item.productId));
    return product ? { ...item, product } : null;
  }).filter(Boolean), [cart]);

  const save = (nextCart) => {
    setCart(nextCart);
    localStorage.setItem('ssp_cart', JSON.stringify(nextCart));
  };

  const updateQty = (productId, delta) => {
    save(cart.map((item) => Number(item.productId) === Number(productId) ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item));
  };

  const remove = (productId) => save(cart.filter((item) => Number(item.productId) !== Number(productId)));
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const making = Math.round(subtotal * 0.08);
  const grandTotal = subtotal + making;

  return (
    <section className="container page-space">
      <div className="page-title-row"><div><span className="eyebrow">Shopping Cart</span><h1>Your Cart</h1></div></div>
      {items.length ? (
        <div className="cart-layout">
          <div className="cart-items">
            {items.map(({ product, quantity }) => (
              <article className="cart-item" key={product.id}>
                <img src={product.image} alt={product.name} />
                <div>
                  <h3>{product.name}</h3>
                  <p>{product.purity} • {product.weight} • {product.metal}</p>
                  <strong>{formatCurrency(product.price)}</strong>
                </div>
                <div className="qty-control">
                  <button onClick={() => updateQty(product.id, -1)}><FiMinus /></button>
                  <span>{quantity}</span>
                  <button onClick={() => updateQty(product.id, 1)}><FiPlus /></button>
                </div>
                <button className="remove-btn" onClick={() => remove(product.id)}><FiTrash2 /></button>
              </article>
            ))}
          </div>

          <aside className="summary-card">
            <h2>Price Summary</h2>
            <p><span>Subtotal</span><strong>{formatCurrency(subtotal)}</strong></p>
            <p><span>Estimated making charges</span><strong>{formatCurrency(making)}</strong></p>
            <p className="grand-total"><span>Total</span><strong>{formatCurrency(grandTotal)}</strong></p>
            <Link to="/checkout" className="primary-btn full">Checkout</Link>
          </aside>
        </div>
      ) : (
        <div className="empty-state"><h2>Your cart is empty</h2><p>Add jewellery designs to continue checkout.</p><Link to="/products" className="primary-btn">Shop Jewellery</Link></div>
      )}
    </section>
  );
}

export default Cart;
