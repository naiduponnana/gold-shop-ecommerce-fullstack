import { useEffect, useState } from 'react';
import { FiMail, FiMapPin, FiPhone } from 'react-icons/fi';
import { api } from '../../services/api.js';

const fallbackStores = [
  { id: 1, name: 'Sai Swarana Palase Main Showroom', city: 'Vijayawada', state: 'Andhra Pradesh', address: 'Main Road Jewellery Market', pincode: '520001', phone: '+91 98765 43210' },
  { id: 2, name: 'Sai Swarana Palase Bridal Studio', city: 'Visakhapatnam', state: 'Andhra Pradesh', address: 'Gold Bazaar Road', pincode: '530001', phone: '+91 98765 43211' }
];

function Contact() {
  const [stores, setStores] = useState(fallbackStores);
  const [locator, setLocator] = useState({ country: 'India', state: '', city: '', zipcode: '' });
  const [form, setForm] = useState({ name: '', mobile: '', email: '', subject: '', message: '' });
  const [status, setStatus] = useState('');

  useEffect(() => {
    api.getStores()
      .then((response) => setStores(response.data.data || fallbackStores))
      .catch(() => setStores(fallbackStores));
  }, []);

  const filteredStores = stores.filter((store) => {
    const cityMatch = !locator.city || store.city.toLowerCase().includes(locator.city.toLowerCase());
    const stateMatch = !locator.state || store.state.toLowerCase().includes(locator.state.toLowerCase());
    const pinMatch = !locator.zipcode || String(store.pincode).includes(locator.zipcode);
    return cityMatch && stateMatch && pinMatch;
  });

  const submitContact = async (event) => {
    event.preventDefault();
    try {
      await api.sendContact(form);
      setStatus('Thank you. Our jewellery consultant will contact you soon.');
      setForm({ name: '', mobile: '', email: '', subject: '', message: '' });
    } catch {
      const saved = JSON.parse(localStorage.getItem('ssp_contacts') || '[]');
      localStorage.setItem('ssp_contacts', JSON.stringify([{ ...form, date: new Date().toISOString() }, ...saved]));
      setStatus('Contact saved locally. Start the backend server to store it in MySQL.');
    }
  };

  return (
    <>
      <section className="page-hero contact-hero">
        <img src="/images/showroom/showroom-banner.svg" alt="Store locator" />
        <div><span className="eyebrow">Contact & Store Locator</span><h1>Visit Sai Swarana Palase showroom</h1></div>
      </section>

      <section className="container section contact-layout">
        <div className="card-panel">
          <h2>Store Locator</h2>
          <div className="form-grid">
            <label>Country<input value={locator.country} onChange={(e) => setLocator({ ...locator, country: e.target.value })} /></label>
            <label>State<input value={locator.state} onChange={(e) => setLocator({ ...locator, state: e.target.value })} /></label>
            <label>City<input value={locator.city} onChange={(e) => setLocator({ ...locator, city: e.target.value })} /></label>
            <label>Zipcode<input value={locator.zipcode} onChange={(e) => setLocator({ ...locator, zipcode: e.target.value })} /></label>
          </div>
          <button className="primary-btn">Search Store</button>

          <div className="store-results">
            {filteredStores.map((store) => (
              <article key={store.id}>
                <h3>{store.name}</h3>
                <p><FiMapPin /> {store.address}, {store.city}, {store.state} - {store.pincode}</p>
                <p><FiPhone /> {store.phone}</p>
              </article>
            ))}
          </div>
        </div>

        <form className="card-panel contact-form" onSubmit={submitContact}>
          <h2>Contact Jewellery Consultant</h2>
          <label>Name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></label>
          <label>Mobile<input value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} required /></label>
          <label>Email<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></label>
          <label>Subject<input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} required /></label>
          <label>Message<textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required /></label>
          <button className="primary-btn full" type="submit"><FiMail /> Submit Enquiry</button>
          {status && <p className="success-message">{status}</p>}
        </form>
      </section>

      <section className="container contact-info-row">
        <p><FiPhone /> +91 98765 43210</p>
        <p><FiMail /> support@saiswaranapalase.com</p>
        <p><FiMapPin /> Andhra Pradesh, India</p>
      </section>
    </>
  );
}

export default Contact;
