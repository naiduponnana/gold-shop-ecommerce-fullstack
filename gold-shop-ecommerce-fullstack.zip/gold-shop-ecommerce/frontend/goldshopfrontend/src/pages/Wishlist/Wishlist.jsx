import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { FiShoppingBag, FiTrash2 } from 'react-icons/fi';
import ProductCard from '../../components/ProductCard.jsx';
import { products } from '../../data/products.js';

const getArray = (key) => { try { return JSON.parse(localStorage.getItem(key)) || []; } catch { return []; } };

function Wishlist() {
  const [wishlist, setWishlist] = useState(getArray('ssp_wishlist'));
  const wishlistProducts = useMemo(() => products.filter((product) => wishlist.includes(product.id)), [wishlist]);

  const remove = (id) => {
    const next = wishlist.filter((item) => item !== id);
    setWishlist(next);
    localStorage.setItem('ssp_wishlist', JSON.stringify(next));
  };

  const moveToCart = (id) => {
    const cart = getArray('ssp_cart');
    const exists = cart.find((item) => Number(item.productId) === Number(id));
    const nextCart = exists ? cart.map((item) => Number(item.productId) === Number(id) ? { ...item, quantity: item.quantity + 1 } : item) : [...cart, { productId: id, quantity: 1 }];
    localStorage.setItem('ssp_cart', JSON.stringify(nextCart));
    remove(id);
  };

  return (
    <section className="container page-space">
      <div className="page-title-row"><div><span className="eyebrow">Wishlist</span><h1>Saved Designs</h1></div></div>
      {wishlistProducts.length ? (
        <div className="wishlist-grid">
          {wishlistProducts.map((product) => (
            <div className="wishlist-card" key={product.id}>
              <ProductCard product={product} />
              <div className="wishlist-actions">
                <button onClick={() => moveToCart(product.id)}><FiShoppingBag /> Move to cart</button>
                <button onClick={() => remove(product.id)}><FiTrash2 /> Remove</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state"><h2>No saved jewellery yet</h2><p>Save your favourite designs and compare them later.</p><Link to="/products" className="primary-btn">Explore Products</Link></div>
      )}
    </section>
  );
}

export default Wishlist;
