import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', mobile: '', email: '', password: '', notifications: true });

  const update = (event) => {
    const { name, value, type, checked } = event.target;
    setForm((current) => ({ ...current, [name]: type === 'checkbox' ? checked : value }));
  };

  const submit = (event) => {
    event.preventDefault();
    localStorage.setItem('ssp_user', JSON.stringify({ id: 1, name: form.name, mobile: form.mobile, email: form.email }));
    navigate('/profile');
  };

  return (
    <section className="auth-page">
      <form className="auth-card register-card" onSubmit={submit}>
        <img src="/images/logo/sai-swarana-logo.svg" alt="Sai Swarana Palase" />
        <span className="eyebrow">Register</span>
        <h1>Create your account</h1>
        <div className="form-grid one">
          <label>Full Name<input name="name" value={form.name} onChange={update} required /></label>
          <label>Mobile Number<input name="mobile" value={form.mobile} maxLength="10" onChange={(e) => setForm((current) => ({ ...current, mobile: e.target.value.replace(/\D/g, '') }))} required /></label>
          <label>Email<input name="email" type="email" value={form.email} onChange={update} required /></label>
          <label>Password<input name="password" type="password" value={form.password} onChange={update} required /></label>
        </div>
        <label className="check-label"><input type="checkbox" name="notifications" checked={form.notifications} onChange={update} /> Authorize WhatsApp/SMS notifications for offers and order updates.</label>
        <button className="primary-btn full" type="submit">Register</button>
        <p className="auth-switch">Already registered? <Link to="/login">Login</Link></p>
      </form>
    </section>
  );
}

export default Register;
