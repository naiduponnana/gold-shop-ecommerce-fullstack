import { Link } from 'react-router-dom';
import { FiPackage } from 'react-icons/fi';
import { products } from '../../data/products.js';

const formatCurrency = (value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

function Orders() {
  const orders = JSON.parse(localStorage.getItem('ssp_orders') || '[]');

  return (
    <section className="container page-space">
      <div className="page-title-row"><div><span className="eyebrow">Order History</span><h1>My Orders</h1></div></div>
      {orders.length ? (
        <div className="orders-list">
          {orders.map((order) => (
            <article className="order-card" key={order.id}>
              <div className="order-top"><span><FiPackage /> {order.id}</span><strong>{order.status}</strong></div>
              <p>Order Date: {order.date}</p>
              {order.items.map((item) => {
                const product = products.find((entry) => entry.id === item.productId);
                return product ? <div className="order-product" key={item.productId}><img src={product.image} alt={product.name} /><span>{product.name} × {item.quantity}</span><strong>{formatCurrency(item.price * item.quantity)}</strong></div> : null;
              })}
              <div className="order-total">Total: {formatCurrency(order.total)}</div>
            </article>
          ))}
        </div>
      ) : (
        <div className="empty-state"><h2>No orders yet</h2><p>Your placed jewellery orders will appear here.</p><Link className="primary-btn" to="/products">Start Shopping</Link></div>
      )}
    </section>
  );
}

export default Orders;
