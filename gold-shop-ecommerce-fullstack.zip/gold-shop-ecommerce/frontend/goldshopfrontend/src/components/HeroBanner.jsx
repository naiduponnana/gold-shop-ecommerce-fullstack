import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';

const slides = [
  {
    eyebrow: 'New Bridal Collection',
    title: 'Celebrate every promise in handcrafted gold',
    text: 'Explore 22K wedding harams, antique necklaces and signature bridal jewellery crafted for timeless ceremonies.',
    image: '/images/banners/banner-hero.svg',
    action: '/products?category=Wedding%20Jewellery'
  },
  {
    eyebrow: 'Diamond Edit',
    title: 'Elegant diamonds for modern everyday luxury',
    text: 'Premium rings, pendants and earrings with refined detailing and certified quality.',
    image: '/images/banners/banner-diamond.svg',
    action: '/products?category=Diamond'
  },
  {
    eyebrow: 'Gold Gifting',
    title: 'Auspicious gifts for every milestone',
    text: 'Choose gold coins, pendants and curated gift jewellery for festivals, weddings and celebrations.',
    image: '/images/banners/banner-gifting.svg',
    action: '/products?category=Gifting'
  }
];

function HeroBanner() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setActive((current) => (current + 1) % slides.length), 4500);
    return () => clearInterval(timer);
  }, []);

  const slide = slides[active];

  return (
    <section className="hero-section">
      <div className="hero-slide container">
        <div className="hero-content">
          <span>{slide.eyebrow}</span>
          <h1>{slide.title}</h1>
          <p>{slide.text}</p>
          <div className="hero-actions">
            <Link to={slide.action} className="primary-btn">Shop Collection</Link>
            <Link to="/contact" className="ghost-btn">Locate Store</Link>
          </div>
        </div>
        <div className="hero-image-card">
          <img src={slide.image} alt={slide.title} />
        </div>
        <button className="slider-btn left" onClick={() => setActive((active - 1 + slides.length) % slides.length)} aria-label="Previous slide"><FiChevronLeft /></button>
        <button className="slider-btn right" onClick={() => setActive((active + 1) % slides.length)} aria-label="Next slide"><FiChevronRight /></button>
      </div>
      <div className="hero-dots">
        {slides.map((item, index) => (
          <button key={item.title} className={index === active ? 'active' : ''} onClick={() => setActive(index)} aria-label={`Open slide ${index + 1}`} />
        ))}
      </div>
    </section>
  );
}

export default HeroBanner;
