import { Link } from 'react-router-dom';

function CategoryCard({ category }) {
  return (
    <Link to={category.path} className="category-card">
      <img src={category.image} alt={category.title} loading="lazy" />
      <span>{category.title}</span>
    </Link>
  );
}

export default CategoryCard;
