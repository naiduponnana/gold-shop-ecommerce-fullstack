import { Link } from 'react-router-dom';
import { FiX } from 'react-icons/fi';

function LoginModal({ open, onClose }) {
  if (!open) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="login-modal">
        <button type="button" className="modal-close" onClick={onClose} aria-label="Close modal"><FiX /></button>
        <img src="/images/logo/sai-swarana-logo.svg" alt="Sai Swarana Palase" />
        <h2>Login to Sai Swarana Palase</h2>
        <p>Access wishlist, cart, orders and premium jewellery updates.</p>
        <Link to="/login" className="primary-btn" onClick={onClose}>Continue Login</Link>
      </div>
    </div>
  );
}

export default LoginModal;
