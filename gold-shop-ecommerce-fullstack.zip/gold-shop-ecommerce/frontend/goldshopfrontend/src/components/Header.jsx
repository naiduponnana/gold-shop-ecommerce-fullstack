import { useMemo, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { FiHeart, FiMapPin, FiMenu, FiSearch, FiShoppingBag, FiUser, FiX } from 'react-icons/fi';

const navItems = [
  { label: 'All Jewellery', path: '/products' },
  { label: 'Gold', path: '/products?category=Gold' },
  { label: 'Diamond', path: '/products?category=Diamond' },
  { label: 'Rings', path: '/products?category=Rings' },
  { label: 'Earrings', path: '/products?category=Earrings' },
  { label: 'Wedding Jewellery', path: '/products?category=Wedding%20Jewellery' },
  { label: 'Jewellery Purchase Plan', path: '/about' },
  { label: 'Gifting', path: '/products?category=Gifting' }
];

function Header() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState('');

  const user = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('ssp_user'));
    } catch {
      return null;
    }
  }, []);

  const handleSearch = (event) => {
    event.preventDefault();
    const query = search.trim();
    navigate(query ? `/products?search=${encodeURIComponent(query)}` : '/products');
    setMenuOpen(false);
  };

  return (
    <header className="site-header">
      <div className="top-strip">
        <span> BIS hallmarked jewellery • Secure checkout • Visit our showroom for live consultation</span>
        <span>Gold Shop: Sai Swarana Palase</span>
      </div>

      <div className="header-main container">
        <Link to="/" className="brand-block" aria-label="Sai Swarana Palase home">
          <img src="/images/logo/sai-swarana-logo.svg" alt="Sai Swarana Palase logo" className="brand-logo" />
          <div>
            <strong>Sai Swarana Palase</strong>
            <span>Gold • Diamond • Wedding Jewellery</span>
          </div>
        </Link>

        <form className="search-box" onSubmit={handleSearch}>
          <FiSearch />
          <input
            type="search"
            value={search}
            placeholder="Search rings, necklaces, bangles..."
            onChange={(event) => setSearch(event.target.value)}
            aria-label="Search jewellery"
          />
          <button type="submit">Search</button>
        </form>

        <div className="header-actions">
          <Link to="/contact" title="Locate store"><FiMapPin /> <span>Store</span></Link>
          <Link to={user ? '/profile' : '/login'} title="Login"><FiUser /> <span>{user ? 'Profile' : 'Login'}</span></Link>
          <Link to="/wishlist" title="Wishlist"><FiHeart /> <span>Wishlist</span></Link>
          <Link to="/cart" title="Cart"><FiShoppingBag /> <span>Cart</span></Link>
          <button className="mobile-menu-btn" type="button" onClick={() => setMenuOpen((value) => !value)} aria-label="Toggle navigation">
            {menuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>

      <nav className={`nav-bar ${menuOpen ? 'show' : ''}`}>
        <div className="container nav-inner">
          {navItems.map((item) => (
            <NavLink key={item.label} to={item.path} onClick={() => setMenuOpen(false)}>
              {item.label}
            </NavLink>
          ))}
        </div>
        <div className="mega-menu container">
          <div>
            <h4>Shop by Category</h4>
            <p>Gold chains, diamond rings, bangles, earrings and daily wear jewellery.</p>
          </div>
          <div>
            <h4>Wedding Edit</h4>
            <p>Bridal harams, antique necklaces, temple jhumkas and engagement rings.</p>
          </div>
          <div>
            <h4>Gold Plans</h4>
            <p>Flexible jewellery purchase plan for future wedding and festive shopping.</p>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Header;
