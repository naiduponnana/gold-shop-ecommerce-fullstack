import { Link } from 'react-router-dom';
import { FaStar } from 'react-icons/fa';
import { FiHeart, FiShoppingBag } from 'react-icons/fi';

const formatCurrency = (value) => new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
}).format(value);

const getStoredArray = (key) => {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch {
    return [];
  }
};

function addToCart(product) {
  const cart = getStoredArray('ssp_cart');
  const existing = cart.find((item) => Number(item.productId) === Number(product.id));
  const updatedCart = existing
    ? cart.map((item) => Number(item.productId) === Number(product.id) ? { ...item, quantity: item.quantity + 1 } : item)
    : [...cart, { productId: product.id, quantity: 1 }];
  localStorage.setItem('ssp_cart', JSON.stringify(updatedCart));
  window.dispatchEvent(new Event('storage'));
}

function addToWishlist(product) {
  const wishlist = getStoredArray('ssp_wishlist');
  if (!wishlist.includes(product.id)) {
    localStorage.setItem('ssp_wishlist', JSON.stringify([...wishlist, product.id]));
    window.dispatchEvent(new Event('storage'));
  }
}

function ProductCard({ product }) {
  if (!product) return null;

  return (
    <article className="product-card">
      <Link to={`/products/${product.id}`} className="product-image-wrap">
        <img src={product.image} alt={product.name} loading="lazy" />
        <span className="purity-badge">{product.purity}</span>
      </Link>
      <div className="product-card-body">
        <Link to={`/products/${product.id}`} className="product-name">{product.name}</Link>
        <div className="rating-row"><FaStar /> {product.rating} <span>• {product.weight}</span></div>
        <div className="price-row">{formatCurrency(product.price)}</div>
        <div className="product-actions-row">
          <button type="button" onClick={() => addToWishlist(product)}><FiHeart /> Wishlist</button>
          <button type="button" onClick={() => addToCart(product)}><FiShoppingBag /> Cart</button>
        </div>
      </div>
    </article>
  );
}

export default ProductCard;
