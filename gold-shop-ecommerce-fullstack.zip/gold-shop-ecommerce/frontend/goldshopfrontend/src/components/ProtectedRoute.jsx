import { Navigate } from 'react-router-dom';

function ProtectedRoute({ children }) {
  const user = localStorage.getItem('ssp_user');
  return user ? children : <Navigate to="/login" replace />;
}

export default ProtectedRoute;
