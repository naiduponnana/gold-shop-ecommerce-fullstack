import { Link } from 'react-router-dom';
import { FiFacebook, FiInstagram, FiMail, FiMapPin, FiPhone, FiShield } from 'react-icons/fi';

function Footer() {
  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <div>
          <Link to="/" className="footer-brand">
            <img src="/images/logo/sai-swarana-logo.svg" alt="Sai Swarana Palase" />
            <span>Sai Swarana Palase</span>
          </Link>
          <p>Premium gold, diamond and wedding jewellery designed with trust, purity and timeless craftsmanship.</p>
          <div className="socials">
            <a href="https://facebook.com" aria-label="Facebook"><FiFacebook /></a>
            <a href="https://instagram.com" aria-label="Instagram"><FiInstagram /></a>
          </div>
        </div>

        <div>
          <h3>Collections</h3>
          <Link to="/products?category=Gold">Gold Jewellery</Link>
          <Link to="/products?category=Diamond">Diamond Jewellery</Link>
          <Link to="/products?category=Wedding%20Jewellery">Wedding Jewellery</Link>
          <Link to="/products?category=Gifting">Gifting</Link>
        </div>

        <div>
          <h3>Customer Care</h3>
          <Link to="/about">About Us</Link>
          <Link to="/contact">Store Locator</Link>
          <Link to="/orders">My Orders</Link>
          <Link to="/profile">My Profile</Link>
        </div>

        <div>
          <h3>Contact</h3>
          <p><FiMapPin /> Main Road, Jewellery Market, Andhra Pradesh, India</p>
          <p><FiPhone /> +91 98765 43210</p>
          <p><FiMail /> support@saiswaranapalase.com</p>
          <p><FiShield /> BIS Hallmarked • Certified Stones • Transparent Billing</p>
        </div>
      </div>
      <div className="footer-bottom">© {new Date().getFullYear()} Sai Swarana Palase. All rights reserved.</div>
    </footer>
  );
}

export default Footer;
