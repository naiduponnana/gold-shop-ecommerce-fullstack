import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

export const api = {
  register: (payload) => apiClient.post('/auth/register', payload),
  login: (payload) => apiClient.post('/auth/login', payload),
  getProfile: (id) => apiClient.get(`/auth/profile/${id}`),

  getProducts: () => apiClient.get('/products'),
  getProduct: (id) => apiClient.get(`/products/${id}`),
  getProductsByCategory: (category) => apiClient.get(`/products/category/${category}`),

  getCart: (userId) => apiClient.get(`/cart/${userId}`),
  addCartItem: (payload) => apiClient.post('/cart', payload),
  updateCartItem: (id, payload) => apiClient.put(`/cart/${id}`, payload),
  deleteCartItem: (id) => apiClient.delete(`/cart/${id}`),

  getWishlist: (userId) => apiClient.get(`/wishlist/${userId}`),
  addWishlistItem: (payload) => apiClient.post('/wishlist', payload),
  deleteWishlistItem: (id) => apiClient.delete(`/wishlist/${id}`),

  getOrders: (userId) => apiClient.get(`/orders/${userId}`),
  createOrder: (payload) => apiClient.post('/orders', payload),

  sendContact: (payload) => apiClient.post('/contact', payload),
  getStores: () => apiClient.get('/stores')
};

export default apiClient;
