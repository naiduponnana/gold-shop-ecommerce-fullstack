import pool from '../config/db.js';

export const createContact = async (req, res, next) => {
  try {
    const { name, mobile, email, subject, message } = req.body;
    if (!name || !mobile || !email || !message) {
      return res.status(400).json({ success: false, message: 'Name, mobile, email and message are required.' });
    }

    const [result] = await pool.query(
      'INSERT INTO contacts (name, mobile, email, subject, message) VALUES (?, ?, ?, ?, ?)',
      [name, mobile, email, subject || 'Jewellery Enquiry', message]
    );
    res.status(201).json({ success: true, message: 'Contact enquiry submitted.', data: { id: result.insertId } });
  } catch (error) {
    next(error);
  }
};

export const getStores = async (req, res, next) => {
  try {
    const [rows] = await pool.query('SELECT * FROM stores WHERE is_active = 1 ORDER BY id ASC');
    res.json({ success: true, data: rows });
  } catch (error) {
    next(error);
  }
};
