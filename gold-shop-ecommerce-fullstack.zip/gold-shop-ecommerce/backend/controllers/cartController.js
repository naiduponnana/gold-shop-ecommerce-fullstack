import pool from '../config/db.js';

export const getCart = async (req, res, next) => {
  try {
    const [rows] = await pool.query(`
      SELECT ci.id, ci.user_id, ci.product_id, ci.quantity, p.name, p.price, p.image_url, p.purity, p.weight
      FROM cart_items ci
      INNER JOIN products p ON ci.product_id = p.id
      WHERE ci.user_id = ?
      ORDER BY ci.id DESC
    `, [req.params.userId]);
    res.json({ success: true, data: rows });
  } catch (error) {
    next(error);
  }
};

export const addCartItem = async (req, res, next) => {
  try {
    const { userId, productId, quantity = 1 } = req.body;
    if (!userId || !productId) return res.status(400).json({ success: false, message: 'userId and productId are required.' });

    await pool.query(`
      INSERT INTO cart_items (user_id, product_id, quantity)
      VALUES (?, ?, ?)
      ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
    `, [userId, productId, quantity]);

    res.status(201).json({ success: true, message: 'Cart item saved.' });
  } catch (error) {
    next(error);
  }
};

export const updateCartItem = async (req, res, next) => {
  try {
    const quantity = Math.max(1, Number(req.body.quantity || 1));
    const [result] = await pool.query('UPDATE cart_items SET quantity = ? WHERE id = ?', [quantity, req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Cart item not found.' });
    res.json({ success: true, message: 'Cart item updated.' });
  } catch (error) {
    next(error);
  }
};

export const deleteCartItem = async (req, res, next) => {
  try {
    const [result] = await pool.query('DELETE FROM cart_items WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Cart item not found.' });
    res.json({ success: true, message: 'Cart item deleted.' });
  } catch (error) {
    next(error);
  }
};
