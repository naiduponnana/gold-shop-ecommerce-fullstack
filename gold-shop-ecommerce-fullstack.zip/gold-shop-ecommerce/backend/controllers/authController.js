import crypto from 'crypto';
import pool from '../config/db.js';

const hashPassword = (password) => crypto.createHash('sha256').update(String(password)).digest('hex');

export const register = async (req, res, next) => {
  try {
    const { name, mobile, email, password } = req.body;
    if (!name || !mobile || !email || !password) {
      return res.status(400).json({ success: false, message: 'Name, mobile, email and password are required.' });
    }

    const [existing] = await pool.query('SELECT id FROM users WHERE mobile = ? OR email = ?', [mobile, email]);
    if (existing.length) {
      return res.status(409).json({ success: false, message: 'User already exists with this mobile or email.' });
    }

    const [result] = await pool.query(
      'INSERT INTO users (name, mobile, email, password_hash) VALUES (?, ?, ?, ?)',
      [name, mobile, email, hashPassword(password)]
    );

    res.status(201).json({ success: true, message: 'Registered successfully.', data: { id: result.insertId, name, mobile, email } });
  } catch (error) {
    next(error);
  }
};

export const login = async (req, res, next) => {
  try {
    const { mobile, email, password } = req.body;
    if ((!mobile && !email) || !password) {
      return res.status(400).json({ success: false, message: 'Mobile/email and password are required.' });
    }

    const [rows] = await pool.query(
      'SELECT id, name, mobile, email, address, created_at FROM users WHERE (mobile = ? OR email = ?) AND password_hash = ?',
      [mobile || '', email || mobile || '', hashPassword(password)]
    );

    if (!rows.length) {
      return res.status(401).json({ success: false, message: 'Invalid login credentials.' });
    }

    res.json({ success: true, message: 'Login successful.', data: rows[0] });
  } catch (error) {
    next(error);
  }
};

export const getProfile = async (req, res, next) => {
  try {
    const [rows] = await pool.query('SELECT id, name, mobile, email, address, created_at FROM users WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: 'User not found.' });
    res.json({ success: true, data: rows[0] });
  } catch (error) {
    next(error);
  }
};
