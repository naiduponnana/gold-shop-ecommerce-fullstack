import pool from '../config/db.js';

export const getWishlist = async (req, res, next) => {
  try {
    const [rows] = await pool.query(`
      SELECT wi.id, wi.user_id, wi.product_id, p.name, p.price, p.image_url, p.purity, p.weight
      FROM wishlist_items wi
      INNER JOIN products p ON wi.product_id = p.id
      WHERE wi.user_id = ?
      ORDER BY wi.id DESC
    `, [req.params.userId]);
    res.json({ success: true, data: rows });
  } catch (error) {
    next(error);
  }
};

export const addWishlistItem = async (req, res, next) => {
  try {
    const { userId, productId } = req.body;
    if (!userId || !productId) return res.status(400).json({ success: false, message: 'userId and productId are required.' });
    await pool.query('INSERT IGNORE INTO wishlist_items (user_id, product_id) VALUES (?, ?)', [userId, productId]);
    res.status(201).json({ success: true, message: 'Wishlist item saved.' });
  } catch (error) {
    next(error);
  }
};

export const deleteWishlistItem = async (req, res, next) => {
  try {
    const [result] = await pool.query('DELETE FROM wishlist_items WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ success: false, message: 'Wishlist item not found.' });
    res.json({ success: true, message: 'Wishlist item deleted.' });
  } catch (error) {
    next(error);
  }
};
