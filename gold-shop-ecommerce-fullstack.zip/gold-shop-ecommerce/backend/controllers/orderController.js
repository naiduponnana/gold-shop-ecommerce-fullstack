import pool from '../config/db.js';

export const getOrders = async (req, res, next) => {
  try {
    const [orders] = await pool.query('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC', [req.params.userId]);
    if (!orders.length) return res.json({ success: true, data: [] });

    const orderIds = orders.map((order) => order.id);
    const [items] = await pool.query(`
      SELECT oi.*, p.name, p.image_url, p.purity, p.weight
      FROM order_items oi
      INNER JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id IN (?)
    `, [orderIds]);

    const data = orders.map((order) => ({
      ...order,
      items: items.filter((item) => item.order_id === order.id)
    }));

    res.json({ success: true, data });
  } catch (error) {
    next(error);
  }
};

export const createOrder = async (req, res, next) => {
  const connection = await pool.getConnection();
  try {
    const { userId, items, billing, totalAmount } = req.body;
    if (!userId || !items?.length || !billing) {
      return res.status(400).json({ success: false, message: 'userId, items and billing details are required.' });
    }

    await connection.beginTransaction();
    const [orderResult] = await connection.query(`
      INSERT INTO orders (user_id, full_name, mobile, email, address, city, state, pincode, total_amount, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Order Placed')
    `, [userId, billing.fullName, billing.mobile, billing.email, billing.address, billing.city, billing.state, billing.pincode, totalAmount]);

    for (const item of items) {
      await connection.query(`
        INSERT INTO order_items (order_id, product_id, quantity, price)
        VALUES (?, ?, ?, ?)
      `, [orderResult.insertId, item.productId, item.quantity, item.price]);
    }

    await connection.query('DELETE FROM cart_items WHERE user_id = ?', [userId]);
    await connection.commit();
    res.status(201).json({ success: true, message: 'Order placed successfully.', data: { orderId: orderResult.insertId } });
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
};
