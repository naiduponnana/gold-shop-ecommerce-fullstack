CREATE DATABASE IF NOT EXISTS goldshop_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE goldshop_db;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS wishlist_items;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS contacts;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS stores;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  mobile VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  address TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  slug VARCHAR(140) NOT NULL UNIQUE,
  image_url VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_id INT NOT NULL,
  name VARCHAR(180) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  metal_type VARCHAR(80) NOT NULL,
  purity VARCHAR(40) NOT NULL,
  weight VARCHAR(40) NOT NULL,
  product_type VARCHAR(80) NOT NULL,
  gender VARCHAR(40) NOT NULL,
  diamond_color VARCHAR(40) DEFAULT 'NA',
  diamond_clarity VARCHAR(40) DEFAULT 'NA',
  collection VARCHAR(100) NULL,
  product_height VARCHAR(40) DEFAULT 'NA',
  product_width VARCHAR(40) DEFAULT 'NA',
  jewellery_type VARCHAR(80) NULL,
  occasion VARCHAR(80) NULL,
  rating DECIMAL(2,1) DEFAULT 4.5,
  image_url VARCHAR(255) NOT NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE cart_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_cart_item (user_id, product_id),
  CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_cart_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE wishlist_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_wishlist_item (user_id, product_id),
  CONSTRAINT fk_wishlist_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_wishlist_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  mobile VARCHAR(20) NOT NULL,
  email VARCHAR(160) NOT NULL,
  address TEXT NOT NULL,
  city VARCHAR(80) NOT NULL,
  state VARCHAR(80) NOT NULL,
  pincode VARCHAR(20) NOT NULL,
  total_amount DECIMAL(12,2) NOT NULL,
  status VARCHAR(60) DEFAULT 'Order Placed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(12,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  mobile VARCHAR(20) NOT NULL,
  email VARCHAR(160) NOT NULL,
  subject VARCHAR(180) NULL,
  message TEXT NOT NULL,
  status VARCHAR(50) DEFAULT 'New',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE stores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  address TEXT NOT NULL,
  city VARCHAR(80) NOT NULL,
  state VARCHAR(80) NOT NULL,
  country VARCHAR(80) DEFAULT 'India',
  pincode VARCHAR(20) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  email VARCHAR(160) NULL,
  opening_hours VARCHAR(160) DEFAULT '10:00 AM - 8:30 PM',
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO categories (name, slug, image_url) VALUES
('Gold', 'Gold', '/images/categories/gold.svg'),
('Diamond', 'Diamond', '/images/categories/diamond.svg'),
('Rings', 'Rings', '/images/categories/rings.svg'),
('Earrings', 'Earrings', '/images/categories/earrings.svg'),
('Wedding Jewellery', 'Wedding Jewellery', '/images/categories/wedding.svg'),
('Gifting', 'Gifting', '/images/categories/gifts.svg');

INSERT INTO products (category_id, name, description, price, metal_type, purity, weight, product_type, gender, diamond_color, diamond_clarity, collection, product_height, product_width, jewellery_type, occasion, rating, image_url) VALUES
(1, 'Aadhya Antique Gold Necklace', 'Premium antique-finish gold necklace with temple-inspired motifs.', 145000, 'Yellow Gold', '22K', '42.58 g', 'Necklace', 'Women', 'NA', 'NA', 'Royal Heritage', '5.8 cm', '14.2 cm', 'Traditional', 'Wedding', 4.8, '/images/products/product-1.svg'),
(2, 'Swarna Lotus Diamond Ring', 'Rose-gold diamond ring with a lotus-inspired crown.', 68500, 'Rose Gold', '18K', '5.24 g', 'Ring', 'Women', 'G-H', 'VS', 'Lotus Glow', '1.2 cm', '2.1 cm', 'Contemporary', 'Engagement', 4.7, '/images/products/product-2.svg'),
(4, 'Palase Pearl Drop Earrings', 'Gold earrings with pearl drop detailing.', 38500, 'Yellow Gold', '22K', '9.88 g', 'Earrings', 'Women', 'NA', 'NA', 'Pearl Edit', '4.3 cm', '1.8 cm', 'Modern', 'Party', 4.6, '/images/products/product-3.svg'),
(5, 'Mangalya Bridal Haram', 'Grand wedding haram with layered detailing and handcrafted finish.', 285000, 'Yellow Gold', '22K', '82.16 g', 'Haram', 'Women', 'NA', 'NA', 'Mangalya', '7.6 cm', '22.8 cm', 'Bridal', 'Wedding', 4.9, '/images/products/product-4.svg'),
(1, 'Minimal Gold Chain', 'Durable minimal gold chain for everyday wear.', 52000, 'Yellow Gold', '22K', '14.72 g', 'Chain', 'Unisex', 'NA', 'NA', 'Daily Gold', 'NA', 'NA', 'Minimal', 'Daily Wear', 4.4, '/images/products/product-5.svg'),
(1, 'Classic Men Gold Kada', 'Premium polished men gold kada with comfortable fit.', 96500, 'Yellow Gold', '22K', '27.05 g', 'Bracelet', 'Men', 'NA', 'NA', 'Men Classic', '1.1 cm', '6.6 cm', 'Classic', 'Daily Wear', 4.5, '/images/products/product-6.svg'),
(2, 'Maya Diamond Pendant', 'White-gold diamond pendant for premium gifting and office wear.', 42500, 'White Gold', '18K', '3.86 g', 'Pendant', 'Women', 'F-G', 'VVS-VS', 'Maya Shine', '2.4 cm', '1.4 cm', 'Modern', 'Gifting', 4.6, '/images/products/product-7.svg'),
(1, 'Nakshi Gold Bangles Pair', 'Nakshi gold bangles with handcrafted festive detailing.', 176000, 'Yellow Gold', '22K', '50.35 g', 'Bangles', 'Women', 'NA', 'NA', 'Nakshi Art', '1.8 cm', '6.1 cm', 'Traditional', 'Festive', 4.8, '/images/products/product-8.svg'),
(4, 'Ruby Gold Stud Earrings', 'Ruby-inspired gold stud earrings for daily wear.', 29500, 'Yellow Gold', '22K', '6.42 g', 'Studs', 'Women', 'NA', 'NA', 'Gem Edit', '1.1 cm', '1.1 cm', 'Minimal', 'Daily Wear', 4.3, '/images/products/product-9.svg'),
(3, 'Premium Couple Rings', 'Premium pair of couple rings with sleek finish.', 84500, 'Yellow Gold', '18K', '11.62 g', 'Ring', 'Couple', 'G-H', 'VS', 'Forever Pair', '1.0 cm', '2.2 cm', 'Contemporary', 'Engagement', 4.7, '/images/products/product-10.svg'),
(6, 'Gifting Gold Coin 8g', '24K gold coin for gifting, investment and celebrations.', 61000, 'Yellow Gold', '24K', '8.00 g', 'Gold Coin', 'Unisex', 'NA', 'NA', 'Auspicious Gifts', '2.2 cm', '2.2 cm', 'Investment', 'Gifting', 4.9, '/images/products/product-11.svg'),
(4, 'Temple Gold Jhumkas', 'Temple-inspired gold jhumkas with classic bell detailing.', 78500, 'Yellow Gold', '22K', '22.45 g', 'Jhumkas', 'Women', 'NA', 'NA', 'Temple Grandeur', '4.8 cm', '2.4 cm', 'Traditional', 'Festive', 4.8, '/images/products/product-12.svg');

INSERT INTO users (name, mobile, email, password_hash, address) VALUES
('Demo Customer', '9876543210', 'demo@saiswaranapalase.com', SHA2('demo123', 256), 'Andhra Pradesh, India');

INSERT INTO stores (name, address, city, state, pincode, phone, email) VALUES
('Sai Swarana Palase Main Showroom', 'Main Road Jewellery Market', 'Vijayawada', 'Andhra Pradesh', '520001', '+91 98765 43210', 'vijayawada@saiswaranapalase.com'),
('Sai Swarana Palase Bridal Studio', 'Gold Bazaar Road', 'Visakhapatnam', 'Andhra Pradesh', '530001', '+91 98765 43211', 'vizag@saiswaranapalase.com'),
('Sai Swarana Palase Gold Boutique', 'Temple Street', 'Rajahmundry', 'Andhra Pradesh', '533101', '+91 98765 43212', 'rajahmundry@saiswaranapalase.com');
