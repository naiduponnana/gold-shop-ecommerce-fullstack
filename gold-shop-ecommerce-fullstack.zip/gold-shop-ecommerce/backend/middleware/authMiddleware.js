function authMiddleware(req, res, next) {
  const userId = req.headers['x-user-id'];
  if (!userId) {
    return res.status(401).json({ success: false, message: 'Unauthorized request. Missing x-user-id header.' });
  }
  req.user = { id: Number(userId) };
  next();
}

export default authMiddleware;
