import express from 'express';
import { createContact, getStores } from '../controllers/contactController.js';

const router = express.Router();

router.post('/contact', createContact);
router.get('/stores', getStores);

export default router;
