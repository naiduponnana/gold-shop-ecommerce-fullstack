import express from 'express';
import { addWishlistItem, deleteWishlistItem, getWishlist } from '../controllers/wishlistController.js';

const router = express.Router();

router.get('/:userId', getWishlist);
router.post('/', addWishlistItem);
router.delete('/:id', deleteWishlistItem);

export default router;
