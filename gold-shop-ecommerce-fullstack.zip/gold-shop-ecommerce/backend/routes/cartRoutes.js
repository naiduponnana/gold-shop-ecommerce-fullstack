import express from 'express';
import { addCartItem, deleteCartItem, getCart, updateCartItem } from '../controllers/cartController.js';

const router = express.Router();

router.get('/:userId', getCart);
router.post('/', addCartItem);
router.put('/:id', updateCartItem);
router.delete('/:id', deleteCartItem);

export default router;
