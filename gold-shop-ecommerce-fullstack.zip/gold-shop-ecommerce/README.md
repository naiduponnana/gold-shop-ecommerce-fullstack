# Sai Swarana Palase - Full-Stack Gold Jewellery E-Commerce Website

This project contains a complete React.js + Vite frontend and Node.js + Express + MySQL backend for a premium gold jewellery shop website.

## Project Structure

```text
gold-shop-ecommerce/
├─ frontend/goldshopfrontend
└─ backend
```

## Frontend Setup

```bash
cd frontend/goldshopfrontend
npm install
npm install react-router-dom react-icons axios
npm run dev
```

Open the Vite URL shown in terminal, usually:

```text
http://localhost:5173
```

## Backend Setup

```bash
cd backend
npm install
npm install express cors dotenv mysql2 nodemon
npm run dev
```

Backend runs on:

```text
http://localhost:5000
```

## MySQL Setup

1. Open MySQL Workbench / phpMyAdmin / terminal.
2. Run this SQL file:

```text
backend/database/goldshop_schema.sql
```

3. Create `.env` inside the `backend` folder by copying `.env.example`.
4. Add your MySQL credentials:

```env
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=goldshop_db
DB_PORT=3306
```

5. Start backend server and then frontend server.

## API Endpoints

### Authentication

- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/profile/:id`

### Products

- GET `/api/products`
- GET `/api/products/:id`
- GET `/api/products/category/:category`

### Cart

- GET `/api/cart/:userId`
- POST `/api/cart`
- PUT `/api/cart/:id`
- DELETE `/api/cart/:id`

### Wishlist

- GET `/api/wishlist/:userId`
- POST `/api/wishlist`
- DELETE `/api/wishlist/:id`

### Orders

- GET `/api/orders/:userId`
- POST `/api/orders`

### Contact / Stores

- POST `/api/contact`
- GET `/api/stores`

## Public Image Path Instructions

All frontend images are placed under:

```text
frontend/goldshopfrontend/public/images/
```

Folders included:

```text
logo/
banners/
categories/
products/
showroom/
```

In React components, use paths like:

```jsx
<img src="/images/logo/sai-swarana-logo.svg" alt="Sai Swarana Palase" />
```

## Demo Login

The SQL seed creates a demo user:

```text
Mobile: 9876543210
Password: demo123
Email: demo@saiswaranapalase.com
```

The frontend also supports localStorage cart, wishlist and orders so the UI remains usable even before backend integration is fully connected.
